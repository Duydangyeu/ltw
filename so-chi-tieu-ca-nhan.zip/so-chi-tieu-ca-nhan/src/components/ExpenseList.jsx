import React from 'react';
import { formatCurrency, formatDate } from '../utils/expense';

export default function ExpenseList({ expenses, onDeleteExpense, loading = false }) {
  const total = expenses.reduce((sum, item) => sum + Number(item.amount), 0);

  const handleDelete = (item) => {
    const confirm = window.confirm(`Bạn có chắc chắn muốn xóa "${item.content}" không?`);
    if (confirm) {
      onDeleteExpense(item.id);
    }
  };

  if (loading) {
    return <div className="loading-box">Đang tải dữ liệu...</div>;
  }

  return (
    <div className="list-container">
      <div className="list-header">
        <h4>Danh sách khoản chi ({expenses.length} mục)</h4>
      </div>

      {expenses.length === 0 ? (
        <div className="empty-box">Chưa có khoản chi nào.</div>
      ) : (
        <table className="expense-table">
          <thead>
            <tr>
              <th>STT</th>
              <th>Nội dung</th>
              <th>Loại chi</th>
              <th>Ngày chi</th>
              <th className="text-right">Số tiền</th>
              <th className="text-center">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {expenses.map((item, index) => (
              <tr key={item.id}>
                <td>{index + 1}</td>
                <td className="content-cell">{item.content}</td>
                <td>
                  <span className={`tag tag-${item.category}`}>{item.category}</span>
                </td>
                <td>{formatDate(item.date)}</td>
                <td className="text-right amount-cell">{formatCurrency(item.amount)}</td>
                <td className="text-center">
                  <button
                    type="button"
                    className="btn-delete"
                    onClick={() => handleDelete(item)}
                  >
                    Xóa
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan="4">
                <strong>Tổng cộng trong danh sách:</strong>
              </td>
              <td className="text-right amount-cell">
                <strong>{formatCurrency(total)}</strong>
              </td>
              <td></td>
            </tr>
          </tfoot>
        </table>
      )}
    </div>
  );
}
