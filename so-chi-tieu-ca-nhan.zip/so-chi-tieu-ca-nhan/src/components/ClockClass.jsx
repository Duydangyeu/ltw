import React, { Component } from 'react';

export default class ClockClass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      time: new Date(),
    };
    this.timer = null;
  }

  componentDidMount() {
    this.timer = setInterval(() => {
      this.setState({ time: new Date() });
    }, 1000);
  }

  componentWillUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    return (
      <div className="clock-box">
        <span className="clock-time">{this.state.time.toLocaleTimeString('vi-VN')}</span>
      </div>
    );
  }
}
