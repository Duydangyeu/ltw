import React from 'react';
import { CATEGORIES } from '../data/sampleExpenses';
import { formatCurrency } from '../utils/expense';

export default function ExpenseStats({ expenses }) {
  const total = expenses.reduce((sum, item) => sum + Number(item.amount), 0);

  return (
    <div className="stats-container">
      <div className="stat-card total-card">
        <span className="stat-title">Tổng Chi Tiêu</span>
        <span className="stat-value">{formatCurrency(total)}</span>
        <span className="stat-desc">{expenses.length} khoản chi</span>
      </div>

      {CATEGORIES.map((cat) => {
        const catExpenses = expenses.filter((item) => item.category === cat);
        const catTotal = catExpenses.reduce((sum, item) => sum + Number(item.amount), 0);
        const percent = total > 0 ? Math.round((catTotal / total) * 100) : 0;

        return (
          <div className="stat-card" key={cat}>
            <span className="stat-title">{cat}</span>
            <span className="stat-value">{formatCurrency(catTotal)}</span>
            <span className="stat-desc">
              {catExpenses.length} khoản ({percent}%)
            </span>
          </div>
        );
      })}
    </div>
  );
}
