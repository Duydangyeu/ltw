import React, { Component } from 'react';
import { CATEGORIES } from '../data/sampleExpenses';
import { validateExpense, getToday } from '../utils/expense';

export default class ExpenseFormClass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      content: '',
      amount: '',
      category: CATEGORIES[0],
      date: getToday(),
      errors: {},
    };
  }

  handleChange = (e) => {
    const { name, value } = e.target;
    this.setState({
      [name]: value,
      errors: { ...this.state.errors, [name]: '' },
    });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const { content, amount, category, date } = this.state;
    const errors = validateExpense({ content, amount, category, date });

    if (Object.keys(errors).length > 0) {
      this.setState({ errors });
      return;
    }

    this.props.onAddExpense({
      content: content.trim(),
      amount: Number(amount),
      category,
      date,
    });

    this.setState({
      content: '',
      amount: '',
      category: CATEGORIES[0],
      date: getToday(),
      errors: {},
    });
  };

  render() {
    const { content, amount, category, date, errors } = this.state;

    return (
      <div className="panel form-panel">
        <h3>Thêm khoản chi</h3>
        <form onSubmit={this.handleSubmit} className="expense-form">
          <div className="form-group form-group-wide">
            <label>Nội dung chi tiêu:</label>
            <input
              type="text"
              name="content"
              value={content}
              onChange={this.handleChange}
              placeholder="Ví dụ: Ăn trưa, xăng xe..."
            />
            {errors.content && <span className="error-text">{errors.content}</span>}
          </div>

          <div className="form-group">
            <label>Số tiền (VNĐ):</label>
            <input
              type="number"
              name="amount"
              value={amount}
              onChange={this.handleChange}
              placeholder="Ví dụ: 35000"
            />
            {errors.amount && <span className="error-text">{errors.amount}</span>}
          </div>

          <div className="form-group">
            <label>Loại chi:</label>
            <select name="category" value={category} onChange={this.handleChange}>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
            {errors.category && <span className="error-text">{errors.category}</span>}
          </div>

          <div className="form-group">
            <label>Ngày chi:</label>
            <input
              type="date"
              name="date"
              value={date}
              onChange={this.handleChange}
            />
            {errors.date && <span className="error-text">{errors.date}</span>}
          </div>

          <div className="form-group form-group-btn">
            <button type="submit" className="btn-primary">
              + Thêm chi tiêu
            </button>
          </div>
        </form>
      </div>
    );
  }
}
