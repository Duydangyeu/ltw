import React from 'react';
import { CATEGORIES } from '../data/sampleExpenses';

export default function ExpenseToolbar({ filter, onFilterChange, search, onSearchChange }) {
  return (
    <div className="toolbar">
      <div className="filter-buttons">
        <button
          type="button"
          className={filter === 'Tất cả' ? 'btn-filter active' : 'btn-filter'}
          onClick={() => onFilterChange('Tất cả')}
        >
          Tất cả
        </button>
        {CATEGORIES.map((cat) => (
          <button
            type="button"
            key={cat}
            className={filter === cat ? 'btn-filter active' : 'btn-filter'}
            onClick={() => onFilterChange(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="search-box">
        <input
          type="text"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Tìm theo nội dung..."
        />
        {search && (
          <button
            type="button"
            className="btn-clear"
            onClick={() => onSearchChange('')}
          >
            ✕
          </button>
        )}
      </div>
    </div>
  );
}
