import React, { Component } from 'react';
import ClockClass from './ClockClass';

export default class HeaderClass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showClock: true,
    };
  }

  toggleClock = () => {
    this.setState((prev) => ({ showClock: !prev.showClock }));
  };

  render() {
    return (
      <header className="app-header">
        <div>
          <h2>Sổ Chi Tiêu Cá Nhân</h2>
          <p className="student-info">Sinh viên: Trần Xuân Duy - MSV: B25DCTV013 (Phần A - Class)</p>
        </div>
        <div className="header-actions">
          <button type="button" className="btn-secondary" onClick={this.toggleClock}>
            {this.state.showClock ? 'Ẩn đồng hồ' : 'Hiện đồng hồ'}
          </button>
          {this.state.showClock && <ClockClass />}
        </div>
      </header>
    );
  }
}
