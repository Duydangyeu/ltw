import React, { useState, useRef } from 'react';
import { CATEGORIES } from '../data/sampleExpenses';
import { validateExpense, getToday } from '../utils/expense';

export default function ExpenseForm({ onAddExpense }) {
  const [content, setContent] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [date, setDate] = useState(getToday());
  const [errors, setErrors] = useState({});

  const contentRef = useRef(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateExpense({ content, amount, category, date });

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    const success = await onAddExpense({
      content: content.trim(),
      amount: Number(amount),
      category,
      date,
    });

    if (success !== false) {
      setContent('');
      setAmount('');
      setCategory(CATEGORIES[0]);
      setDate(getToday());
      setErrors({});
      contentRef.current.focus();
    }
  };

  return (
    <div className="panel form-panel">
      <h3>Thêm khoản chi</h3>
      <form onSubmit={handleSubmit} className="expense-form">
        <div className="form-group form-group-wide">
          <label>Nội dung chi tiêu:</label>
          <input
            ref={contentRef}
            type="text"
            value={content}
            onChange={(e) => {
              setContent(e.target.value);
              setErrors({ ...errors, content: '' });
            }}
            placeholder="Ví dụ: Ăn trưa, xăng xe..."
          />
          {errors.content && <span className="error-text">{errors.content}</span>}
        </div>

        <div className="form-group">
          <label>Số tiền (VNĐ):</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => {
              setAmount(e.target.value);
              setErrors({ ...errors, amount: '' });
            }}
            placeholder="Ví dụ: 35000"
          />
          {errors.amount && <span className="error-text">{errors.amount}</span>}
        </div>

        <div className="form-group">
          <label>Loại chi:</label>
          <select
            value={category}
            onChange={(e) => {
              setCategory(e.target.value);
              setErrors({ ...errors, category: '' });
            }}
          >
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
          {errors.category && <span className="error-text">{errors.category}</span>}
        </div>

        <div className="form-group">
          <label>Ngày chi:</label>
          <input
            type="date"
            value={date}
            onChange={(e) => {
              setDate(e.target.value);
              setErrors({ ...errors, date: '' });
            }}
          />
          {errors.date && <span className="error-text">{errors.date}</span>}
        </div>

        <div className="form-group form-group-btn">
          <button type="submit" className="btn-primary">
            + Thêm chi tiêu
          </button>
        </div>
      </form>
    </div>
  );
}
