import React, { useState, useContext } from 'react';
import { ThemeContext } from '../context/ThemeContext';
import { useClock } from '../hooks/useClock';

export default function HeaderFunction() {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const [showClock, setShowClock] = useState(true);
  const time = useClock();

  return (
    <header className="app-header">
      <div>
        <h2>Sổ Chi Tiêu Cá Nhân</h2>
        <p className="student-info">Sinh viên: Trần Xuân Duy - MSV: B25DCTV013 (Phần B - Hooks)</p>
      </div>
      <div className="header-actions">
        <button type="button" className="btn-secondary" onClick={toggleTheme}>
          {theme === 'light' ? '🌙 Chế độ tối' : '☀️ Chế độ sáng'}
        </button>
        <button type="button" className="btn-secondary" onClick={() => setShowClock(!showClock)}>
          {showClock ? 'Ẩn đồng hồ' : 'Hiện đồng hồ'}
        </button>
        {showClock && (
          <div className="clock-box">
            <span className="clock-time">{time.toLocaleTimeString('vi-VN')}</span>
          </div>
        )}
      </div>
    </header>
  );
}
