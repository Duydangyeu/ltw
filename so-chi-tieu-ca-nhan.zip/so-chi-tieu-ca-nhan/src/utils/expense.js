export function formatCurrency(amount) {
  return Number(amount || 0).toLocaleString('vi-VN') + ' đ';
}

export function formatDate(dateString) {
  if (!dateString) return '';
  const parts = String(dateString).slice(0, 10).split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateString;
}

export function getToday() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function validateExpense(item) {
  const errors = {};
  if (!item.content || !item.content.trim()) {
    errors.content = 'Vui lòng nhập nội dung khoản chi';
  }
  if (!item.amount || Number(item.amount) <= 0) {
    errors.amount = 'Số tiền phải là số lớn hơn 0';
  }
  if (!item.category) {
    errors.category = 'Vui lòng chọn loại chi';
  }
  if (!item.date) {
    errors.date = 'Vui lòng chọn ngày chi';
  }
  return errors;
}
