import React, { useState } from 'react';
import ClassApp from './ClassApp';
import FunctionApp from './FunctionApp';
import { ThemeProvider } from './context/ThemeContext';

export default function App() {
  const [tab, setTab] = useState('class');

  return (
    <ThemeProvider>
      <div className="main-wrapper">
        <div className="top-nav">
          <div className="student-badge">
            <strong>Trần Xuân Duy</strong> - MSV: <strong>B25DCTV013</strong>
          </div>
          <div className="nav-buttons">
            <button
              type="button"
              className={tab === 'class' ? 'nav-btn active' : 'nav-btn'}
              onClick={() => setTab('class')}
            >
              Phần A: Class Component
            </button>
            <button
              type="button"
              className={tab === 'function' ? 'nav-btn active' : 'nav-btn'}
              onClick={() => setTab('function')}
            >
              Phần B: Function + Hooks
            </button>
          </div>
        </div>

        {tab === 'class' ? <ClassApp key="class" /> : <FunctionApp key="function" />}

        <footer className="footer">
          Bài tập lớn React: Sổ chi tiêu cá nhân - Trần Xuân Duy (B25DCTV013)
        </footer>
      </div>
    </ThemeProvider>
  );
}
