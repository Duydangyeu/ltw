import React, { Component } from 'react';
import HeaderClass from './components/HeaderClass';
import ExpenseFormClass from './components/ExpenseFormClass';
import ExpenseStats from './components/ExpenseStats';
import ExpenseToolbar from './components/ExpenseToolbar';
import ExpenseList from './components/ExpenseList';
import { SAMPLE_EXPENSES } from './data/sampleExpenses';

export default class ClassApp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expenses: [...SAMPLE_EXPENSES],
      filter: 'Tất cả',
      search: '',
      debouncedSearch: '',
    };
    this.searchTimer = null;
  }

  componentDidMount() {
    this.updateTitle();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.expenses !== this.state.expenses) {
      this.updateTitle();
    }

    if (prevState.search !== this.state.search) {
      clearTimeout(this.searchTimer);
      this.searchTimer = setTimeout(() => {
        this.setState({ debouncedSearch: this.state.search });
      }, 350);
    }
  }

  componentWillUnmount() {
    if (this.searchTimer) {
      clearTimeout(this.searchTimer);
    }
  }

  updateTitle = () => {
    const total = this.state.expenses.reduce((sum, item) => sum + Number(item.amount), 0);
    document.title = `Tổng chi: ${total.toLocaleString('vi-VN')} đ | Sổ chi tiêu`;
  };

  handleAdd = (newExpense) => {
    const item = {
      ...newExpense,
      id: 'class-' + Date.now(),
    };
    this.setState((prevState) => ({
      expenses: [item, ...prevState.expenses],
    }));
  };

  handleDelete = (id) => {
    this.setState((prevState) => ({
      expenses: prevState.expenses.filter((item) => item.id !== id),
    }));
  };

  handleFilterChange = (category) => {
    this.setState({ filter: category });
  };

  handleSearchChange = (keyword) => {
    this.setState({ search: keyword });
  };

  render() {
    const { expenses, filter, search, debouncedSearch } = this.state;

    const filteredExpenses = expenses.filter((item) => {
      const matchCategory = filter === 'Tất cả' || item.category === filter;
      const matchSearch = item.content.toLowerCase().includes(debouncedSearch.toLowerCase().trim());
      return matchCategory && matchSearch;
    });

    return (
      <div className="app-container">
        <HeaderClass />
        <ExpenseStats expenses={expenses} />
        <ExpenseFormClass onAddExpense={this.handleAdd} />
        <div className="panel list-panel">
          <ExpenseToolbar
            filter={filter}
            onFilterChange={this.handleFilterChange}
            search={search}
            onSearchChange={this.handleSearchChange}
          />
          <ExpenseList
            expenses={filteredExpenses}
            onDeleteExpense={this.handleDelete}
          />
        </div>
      </div>
    );
  }
}
