export const CATEGORIES = ['Ăn uống', 'Đi lại', 'Học tập', 'Giải trí'];

export const SAMPLE_EXPENSES = [
  { id: 'sample-1', content: 'Ăn sáng', amount: 30000, category: 'Ăn uống', date: '2026-11-10' },
  { id: 'sample-2', content: 'Gửi xe', amount: 10000, category: 'Đi lại', date: '2026-11-10' },
  { id: 'sample-3', content: 'Mua giáo trình', amount: 85000, category: 'Học tập', date: '2026-11-09' },
  { id: 'sample-4', content: 'Xem phim', amount: 70000, category: 'Giải trí', date: '2026-11-08' },
  { id: 'sample-5', content: 'Ăn trưa', amount: 50000, category: 'Ăn uống', date: '2026-11-08' },
];
