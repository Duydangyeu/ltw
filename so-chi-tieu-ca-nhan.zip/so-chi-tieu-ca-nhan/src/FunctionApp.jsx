import React, { useState, useEffect, useMemo } from 'react';
import HeaderFunction from './components/HeaderFunction';
import ExpenseForm from './components/ExpenseForm';
import ExpenseStats from './components/ExpenseStats';
import ExpenseToolbar from './components/ExpenseToolbar';
import ExpenseList from './components/ExpenseList';
import useFetch from './hooks/useFetch';
import useDebounce from './hooks/useDebounce';

export default function FunctionApp() {
  const { expenses, loading, error, addExpense, deleteExpense, refresh } = useFetch();
  const [filter, setFilter] = useState('Tất cả');
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 350);

  const filteredExpenses = useMemo(() => {
    return expenses.filter((item) => {
      const matchCategory = filter === 'Tất cả' || item.category === filter;
      const matchSearch = item.content.toLowerCase().includes(debouncedSearch.toLowerCase().trim());
      return matchCategory && matchSearch;
    });
  }, [expenses, filter, debouncedSearch]);

  const totalAmount = useMemo(() => {
    return expenses.reduce((sum, item) => sum + Number(item.amount), 0);
  }, [expenses]);

  useEffect(() => {
    document.title = `Tổng chi: ${totalAmount.toLocaleString('vi-VN')} đ | Sổ chi tiêu`;
  }, [totalAmount]);

  return (
    <div className="app-container">
      <HeaderFunction />

      {error && (
        <div className="error-alert">
          <span>Lỗi kết nối: {error}</span>
          <button type="button" onClick={refresh}>Thử lại</button>
        </div>
      )}

      <ExpenseStats expenses={expenses} />
      <ExpenseForm onAddExpense={addExpense} />

      <div className="panel list-panel">
        <ExpenseToolbar
          filter={filter}
          onFilterChange={setFilter}
          search={search}
          onSearchChange={setSearch}
        />
        <ExpenseList
          expenses={filteredExpenses}
          onDeleteExpense={deleteExpense}
          loading={loading}
        />
      </div>
    </div>
  );
}
