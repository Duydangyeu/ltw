import { useState, useEffect } from 'react';
import { SAMPLE_EXPENSES } from '../data/sampleExpenses';

const API_URL = import.meta.env.VITE_MOCKAPI_URL || '';

export default function useFetch() {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      if (API_URL) {
        const res = await fetch(API_URL);
        if (!res.ok) {
          throw new Error('Lỗi khi lấy dữ liệu từ MockAPI');
        }
        const data = await res.json();
        setExpenses(Array.isArray(data) ? data : []);
      } else {
        const saved = localStorage.getItem('expenses_data');
        if (saved) {
          setExpenses(JSON.parse(saved));
        } else {
          setExpenses(SAMPLE_EXPENSES);
          localStorage.setItem('expenses_data', JSON.stringify(SAMPLE_EXPENSES));
        }
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const addExpense = async (newItem) => {
    try {
      if (API_URL) {
        const res = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newItem),
        });
        if (!res.ok) {
          throw new Error('Lỗi khi thêm khoản chi');
        }
        const created = await res.json();
        setExpenses((prev) => [created, ...prev]);
      } else {
        const created = {
          ...newItem,
          id: Date.now().toString(),
        };
        setExpenses((prev) => {
          const next = [created, ...prev];
          localStorage.setItem('expenses_data', JSON.stringify(next));
          return next;
        });
      }
      return true;
    } catch (err) {
      alert(err.message);
      return false;
    }
  };

  const deleteExpense = async (id) => {
    try {
      if (API_URL) {
        const res = await fetch(`${API_URL}/${id}`, {
          method: 'DELETE',
        });
        if (!res.ok) {
          throw new Error('Lỗi khi xóa khoản chi');
        }
        setExpenses((prev) => prev.filter((item) => String(item.id) !== String(id)));
      } else {
        setExpenses((prev) => {
          const next = prev.filter((item) => String(item.id) !== String(id));
          localStorage.setItem('expenses_data', JSON.stringify(next));
          return next;
        });
      }
      return true;
    } catch (err) {
      alert(err.message);
      return false;
    }
  };

  return {
    expenses,
    loading,
    error,
    addExpense,
    deleteExpense,
    refresh: fetchData,
  };
}
