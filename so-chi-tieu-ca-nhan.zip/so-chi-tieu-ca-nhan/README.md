# BÁO CÁO BÀI TẬP: SỔ CHI TIÊU CÁ NHÂN (REACT)

- **Sinh viên:** Trần Xuân Duy
- **Mã sinh viên:** B25DCTV013

---

## 1. Giới thiệu bài tập

Ứng dụng "Sổ chi tiêu cá nhân" được xây dựng hai lần theo yêu cầu của đề bài:
1. **Phần A – Class Component:** Sử dụng các thành phần dạng lớp, quản lý state và xử lý vòng đời qua các phương thức `componentDidMount`, `componentDidUpdate`, `componentWillUnmount`.
2. **Phần B – Function Component + Hooks:** Viết lại toàn bộ bằng functional components kết hợp React Hooks (`useState`, `useEffect`, `useRef`, `useContext`, `useMemo`), gọi API qua custom hook `useFetch`.
3. **Yêu cầu nâng cao:** Tách custom hook `useClock`, thống kê chi tiêu theo từng danh mục (kèm tỷ lệ %), ô tìm kiếm có độ trễ (debounce).

---

## 2. Cách chạy ứng dụng

1. Cài đặt thư viện:
   ```bash
   npm install
   ```
2. Chạy ứng dụng:
   ```bash
   npm run dev
   ```
3. Mở trình duyệt tại địa chỉ: `http://localhost:5173/`

---

## 3. Cấu hình MockAPI (Phần B)

Ứng dụng thực hiện các thao tác: lấy danh sách (GET), thêm mới (POST), xóa (DELETE).

- Nếu có link MockAPI, tạo file `.env` ở thư mục gốc:
  ```env
  VITE_MOCKAPI_URL=https://<id-du-an>.mockapi.io/api/v1/expenses
  ```
- Nếu không có file `.env`, ứng dụng sẽ tự động lưu dữ liệu vào `localStorage` trên trình duyệt để chạy offline bình thường.

---

## 4. Hooks đã giúp khắc phục các thách thức của Class Component như thế nào?

Trong quá trình làm bài, việc chuyển từ Class Component sang Function Component + Hooks mang lại các ưu điểm rõ rệt:

1. **Gom gọn logic vòng đời với `useEffect`:**
   - Ở Class Component, logic của một tính năng bị chia tách ra nhiều nơi (ví dụ: đồng hồ phải tạo timer ở `componentDidMount`, xóa timer ở `componentWillUnmount`; cập nhật tiêu đề tab phải viết ở cả `componentDidMount` và `componentDidUpdate`).
   - Ở Function Component, `useEffect` cho phép viết khởi tạo và hàm dọn dẹp (`cleanup`) ngay trong cùng một khối lệnh, giúp code ngắn gọn và không bị quên hủy timer.

2. **Dễ dàng tái sử dụng logic bằng Custom Hooks:**
   - Với Class Component, muốn chia sẻ logic gọi API hay logic đồng hồ giữa nhiều component rất phức tạp (phải dùng Higher-Order Component hoặc Render Props).
   - Với Hooks, chỉ cần viết custom hook (`useClock`, `useFetch`, `useDebounce`) như một hàm JavaScript bình thường, component nào cần thì gọi vào dùng rất nhanh.

3. **Quản lý state đơn giản hơn với `useState`:**
   - Class Component phải gom toàn bộ state vào đối tượng `this.state` và cập nhật bằng `this.setState`, dễ gặp lỗi về ngữ cảnh con trỏ `this`.
   - Function Component dùng `useState` tách riêng từng biến (`filter`, `search`, `content`), cú pháp tự nhiên và dễ theo dõi.

4. **Thao tác DOM trực quan với `useRef`:**
   - `useRef` giúp truy cập trực tiếp vào ô input để gọi hàm `.focus()` sau khi thêm mới khoản chi thành công, đơn giản hơn nhiều so với `React.createRef()` của Class Component.

5. **Chia sẻ dữ liệu toàn cục dễ dàng với `useContext`:**
   - Không cần truyền props qua nhiều tầng component (prop drilling), component con chỉ cần gọi `useContext(ThemeContext)` là có thể lấy trạng thái và hàm đổi chế độ sáng/tối.
